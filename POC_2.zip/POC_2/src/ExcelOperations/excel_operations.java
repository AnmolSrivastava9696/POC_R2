package ExcelOperations;
//This class contains methods for performing operations in an Excel file such as reading data from excel and writing data into excel

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import PageObjectModel_POC2.testData;
import javafx.scene.input.DataFormat;

public class excel_operations 
{
	//read_Excel reads data from Excel File on the basis of rowIndex given as inputParameter
	public static testData readExcel(int rowIndex) 
	{
		try {
			//
			File f=new File("C:\\\\Users\\\\anmol.srivastava\\\\Desktop\\\\POC_2.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook workbook =new XSSFWorkbook(fis);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			XSSFRow row =sheet.getRow(rowIndex);
			DataFormatter df=new DataFormatter();
			List<XSSFCell> cell_list=new ArrayList<>();
			for(int i=0;i<9;i++) 
			{
				cell_list.add(row.getCell(i));
			}
			String tc_id =df.formatCellValue(cell_list.get(0));
			String first_name=df.formatCellValue(cell_list.get(1));
			String last_name=df.formatCellValue(cell_list.get(2));
			String email=df.formatCellValue(cell_list.get(3));
			String password=df.formatCellValue(cell_list.get(4));
			String expectedProfileName=df.formatCellValue(cell_list.get(5));
			testData td=new testData(tc_id,first_name,last_name,email,password,expectedProfileName);
			return td;
			
	     	}
		catch(Exception e) 
		{
			e.printStackTrace();
			return null;
		}
		
		
		
	}
  //writeTestResults write test_results into an Excel File 
  //The row in which data is to be inserted and the data to be inserted are given as input parameters
	public static void writeTitleTestResult(String result,int rowIndex) 
	{
		
		try 
		{
			File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\POC_2.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook workbook=new XSSFWorkbook(fis);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			XSSFRow row=sheet.getRow(rowIndex);
			XSSFCell actual_result_cell=row.createCell(13);
			actual_result_cell.setCellValue(result);
			FileOutputStream fos=new FileOutputStream(f);
			workbook.write(fos);
			
			
			
			
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	//writeActualResult write actualResult obtained after registration into excel file
	
	public static void writeActuals(String result,String result2,String result3,String result4,int rowIndex) 
	{
		
		try 
		{
			File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\POC_2.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook workbook=new XSSFWorkbook(fis);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			XSSFRow row=sheet.getRow(rowIndex);
			XSSFCell actual_result_cell=row.createCell(9);
			actual_result_cell.setCellValue(result);
			XSSFCell actual_result_cell_2=row.createCell(10);
			actual_result_cell_2.setCellValue(result2);
			XSSFCell actual_result_cell_3=row.createCell(11);
			actual_result_cell_3.setCellValue(result3);
			XSSFCell actual_result_cell_4=row.createCell(12);
			actual_result_cell_4.setCellValue(result4);
			FileOutputStream fos=new FileOutputStream(f);
			workbook.write(fos);
			
			
			
			
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	
	
	

}
