package PageObjectModel_POC2;

public class testData
{
	String tc_id;
	String firstName;
	String lastName;
	String email;
	String password;
	
	String expectedProfileName;
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getEmail() {
		return email;
	}
	public String getPassword() {
		return password;
	}
	
	public String expectedProfileName() 
	{
		return expectedProfileName;
	}
	public testData(String tc_id,String firstName, String lastName, String email, String password,String expectedProfileName) 
	{
		
		this.tc_id=tc_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		
		this.expectedProfileName=expectedProfileName;
	}
	

}
