package Presentation;

public class Lined 
{
public static String upperLowerBorder() 
{
	return "======================================================================================";
}
public static String middleBorder() 
{
	
	  return "-------------------------- ";
	
}
}
