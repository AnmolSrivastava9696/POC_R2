package TestRunnerPOC_2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import ExcelOperations.excel_operations;
import PageObjectModel_POC2.AuthenticationPage;
import PageObjectModel_POC2.HomePage;
import PageObjectModel_POC2.MyAccount;
import PageObjectModel_POC2.testData;
import Presentation.Lined;

public class TestProfileName extends TestTitle
{
int i=0;
	   
	   @Test(dataProvider="datadata",priority=4)
	   public void verifyMyAccountPageTitle(String emailId,String password) 
	   {
		  testData td=testdatas.get(i);
	   	 ap_poc_2=new AuthenticationPage(driver);
		 ap_poc_2.doLogin(emailId, password); 
		 Wait wait=new WebDriverWait(driver,20); 
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")));
		 MyAccount ma_poc_2=new MyAccount(driver);
		 String actualAccountName=ma_poc_2.getMyAccountName();
		 String expectedAccountName=td.expectedProfileName();
		 
		 SoftAssert sa=new SoftAssert();
		 sa.assertEquals(actualAccountName,expectedAccountName);
		 sa.assertAll();
		   log.info("Verifition for Profile Name Started");
		   log.info(" Expected: "+expectedAccountName+" Actual: "+ actualAccountName);
		   log.info(Lined.upperLowerBorder());
		  log.info(Lined.middleBorder()+"Profile Name for "+emailId+" displayed correctly"+Lined.middleBorder());
		 
		 ma_poc_2.logout();
		 
		 i++;
		 
	   }
		   
	   @DataProvider(name="datadata")
		  public String[][]getExpectedResults() 
		  {
			  
			  String[][] expectedResults=new String[3][2];
			  for(int i=0;i<3;i++) 
			  {
				 testData td=testdatas.get(i);
				 
				 String email= td.getEmail();
				 String password=td.getPassword();
				  
				 expectedResults[i][0]=email;
				 expectedResults[i][1]=password;
				 
				 
				 
			  }
			  return expectedResults;
		  }
	
	
	
}

